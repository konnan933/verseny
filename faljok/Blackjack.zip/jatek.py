import seged

print("""Egy ismert kártyajátékot a black jack-et lehet játszani egy gép ellen, véletlenszerű kártyákkal""")
ujra=0
while ujra!=1:
    pakli=[]
    for i in range(2,11,1):
        pakli.append(i)

    #gép lapjai
    gep1=seged.lapkeres(pakli)
    gep2=seged.lapkeres(pakli)
    #gép lapjai vege

    #jatekoslapjai
    jatekos1=seged.lapkeres(pakli)
    jatekos2=seged.lapkeres(pakli)
    #jatekoslapjai vege

    jatekossum=jatekos1+jatekos2
    seged.kiirasS(jatekos1,jatekos2,jatekossum)

    #ujrahuzas
    while jatekossum<16:
        print("Kötelező húznia még egy lapot")
        jatekos3=seged.lapkeres(pakli)
        jatekossum=jatekossum+jatekos3
        seged.kiiras(jatekos3,jatekossum)
    nem=0
    while jatekossum<21 and nem!=1:
        a=input("Szeretne lapot húzni?(i/n)")
        if a=="i":
            jatekos4=seged.lapkeres(pakli)
            jatekossum=jatekossum+jatekos4
            seged.kiiras(jatekos4,jatekossum)
        elif a=="n":
            nem+=1
    gepsum=gep1+gep2
    seged.kiirasS(gep1,gep2,gepsum)
    while gepsum<16:
        print("A gépnek kötelező húnia egy lapot")
        gep3=seged.lapkeres(pakli)
        gepsum=gepsum+gep3
        seged.kiiras(gep3,gepsum)
    if jatekossum==gepsum:
        print("Döntetlen")
    elif jatekossum>21 and gepsum>21:
        if jatekossum<gepsum:
            seged.jatekosnyer()
        else:
            seged.gepnyer()
    elif jatekossum<=21 and gepsum<=21:
        if jatekossum>gepsum:
            seged.jatekosnyer()
        else:
            seged.gepnyer()
    elif jatekossum<=21 and gepsum>21:
        seged.jatekosnyer()
    elif jatekossum>21 and gepsum<=21:
        seged.gepnyer()
    v=input("Szeretne újra játszani?i/n")
    if v=="n":
        ujra+=1
    else:
        print("")
        print("Új játék kezdődik")


