import random

def lapkeres(pakli):
    sors = random.randint(0, 12)
    if sors <= 8:
        ertek = pakli[sors]
    elif sors == 9:
        ertek = 10
    elif sors == 10:
        ertek = 10
    elif sors == 11:
        ertek = 10
    elif sors == 12:
        ertek = 11
    return ertek

def kiirasS(ertek1,ertek2,ertek3):
    print("A játékos lapjai:", ertek1, "és", ertek2)
    print("A játékos lapjainak összege:", ertek3)

def kiiras(ertek1,ertek2):
    print("A játékos következő lapja:", ertek1)
    print("A játékos lapjainak összege:", ertek2)

def gepnyer():
    print("A gép nyert")
def jatekosnyer():
    print("A játékos nyert!")





