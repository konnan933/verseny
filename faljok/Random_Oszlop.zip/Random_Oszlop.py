import random

sor1 = []
sor2 = []
sor3 = []

szamlalo1 = 0
szamlalo2 = 0
szamlalo3 = 0

szam1 = [1]
szam2 = [2]
szam3 = [3]

uresoszlop1 = "[ ]"
uresoszlop2 = "[ ]"
uresoszlop3 = "[ ]"

szamlista = [szam1, szam2, szam3]

sorlista = [sor1, sor2, sor3]

while szamlalo1 != 3 or szamlalo2 != 3 or szamlalo3 != 3:
    random.shuffle(szamlista)
    if len(sor1) != 3:
        if szamlista[0] == szam1 and szamlalo1 != 3:
            sorlista[0].append(szamlista[0])
            szamlalo1 += 1
        elif szamlista[0] == szam2 and szamlalo2 != 3:
            sorlista[0].append(szamlista[0])
            szamlalo2 += 1
        elif szamlista[0] == szam3 and szamlalo3 != 3:
            sorlista[0].append(szamlista[0])
            szamlalo3 += 1
        random.shuffle(szamlista)
    if len(sor2) != 3:
        if szamlista[0] == szam1 and szamlalo1 != 3:
            sorlista[1].append(szamlista[0])
            szamlalo1 += 1
        elif szamlista[0] == szam2 and szamlalo2 != 3:
            sorlista[1].append(szamlista[0])
            szamlalo2 += 1
        elif szamlista[0] == szam3 and szamlalo3 != 3:
            sorlista[1].append(szamlista[0])
            szamlalo3 += 1
        random.shuffle(szamlista)
    if len(sor3) != 3:
        if szamlista[0] == szam1 and szamlalo1 != 3:
            sorlista[2].append(szamlista[0])
            szamlalo1 += 1
        elif szamlista[0] == szam2 and szamlalo2 != 3:
            sorlista[2].append(szamlista[0])
            szamlalo2 += 1
        elif szamlista[0] == szam3 and szamlalo3 != 3:
            sorlista[2].append(szamlista[0])
            szamlalo3 += 1
sor1.append("|")
sor2.append("|")
sor3.append("|")

sor1.append(uresoszlop1)
sor2.append(uresoszlop2)
sor3.append(uresoszlop3)

print(' '.join(map(str, sor1)))
print(' '.join(map(str, sor2)))
print(' '.join(map(str, sor3)))
