package IttaPiros;

import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.Random;
import java.util.Scanner;

public class Ittapiros {

    public static void main(String[] args) throws UnsupportedEncodingException {
        System.out.println("Itt a piros hol a piros játék!");
        String valasz2 = "Nem talált! %d --> %d\n";
        int feltesz = 0;
        boolean tet = false;
        int penz = 500;
        String penznem = "HUF";
        Scanner scan = new Scanner(System.in);
        System.out.println("Milyen nagyságú pályán szeretnél játszani?");
        int palyahossz = scan.nextInt();
        String palya = "_ ";

        for (int i = 0; i < palyahossz; i++) {
            System.out.print(palya);
        }
        System.out.println(" ");
        for (int i = 1; i < palyahossz + 1; i++) {
            System.out.print(i + " ");
        }

        String igaz = "igen";
        String hamis = "nem";
        Scanner scan1 = new Scanner(new InputStreamReader(System.in, "ISO-8859-1"));
        System.out.println("\nSzeretnél-e pénzre játszani ? igen | nem");
        String valasz = scan1.nextLine();

        if (valasz.equals(igaz)) {
            tet = true;
            System.out.printf("Pénz=%d %s", penz, penznem);
        } else if (!valasz.equals(igaz) || !valasz.equals(hamis)) {
            System.out.println("Hibás bevitel!");
            System.out.println("Autómatikus pénz nélküli játék!");
        }
        int szorzo = 1;

        if (tet) {
            szorzo *= palyahossz;
            Scanner scan2 = new Scanner(System.in);
            System.out.println("\nMennyi pénzel szeretne játszani?");
            feltesz = scan2.nextInt();
            if (feltesz < 0 || feltesz > penz) {
                System.out.println("Nem megfelelő összeg!");
            } else {
                penz -= feltesz;
            }
        }

        //bekeres();
        System.out.println(" ");
        Scanner sc = new Scanner(System.in);
        System.out.print("Kérem adja meg a tippet!");
        int tipp = sc.nextInt();
        String osszeg = " ";
        String nyer = " ";
        String veszt = " ";
        int nyeremeny = feltesz * szorzo;
        Random rnd = new Random();
        int maxpohar = palyahossz;
        int r = rnd.nextInt(palyahossz) + 1;
        int holagolyo = r;
        String helyes = "o ", helytelen = "x ", vonal = "- ";
        String megoldas = "";
        int legkis = 0;
        if (tipp > maxpohar || tipp <= 0) {
            System.out.println("Hibás érték!");
        }
        boolean jo = tipp == holagolyo;
        boolean rossztipp = tipp != holagolyo;
        if (jo) {
            penz += nyeremeny;
            valasz2 = "Talált! %d --> %d\n";
            nyer = "A nyereményed= %d\n";
            osszeg = "A jelenlegi összeged: %d\n";
//            System.out.printf("A nyereményed= %d\n",nyeremeny);
//            System.out.printf("A jelenlegi összeged: %d\n",penz);
            while (maxpohar != legkis) {
                legkis += 1;
                if (tipp == legkis) {
                    megoldas += helyes;

                } else {
                    megoldas += vonal;

                }
            }
        } else if (rossztipp == true) {
            veszt = "Veszteség: -%d\n";
            osszeg = "A jelenlegi összeged: %d\n";
//                System.out.printf("Veszteség: -%d\n",feltesz);
//                System.out.printf("A jelenlegi összeged: %d\n",penz);
            while (maxpohar != legkis) {
                legkis += 1;
                if (tipp == legkis) {
                    megoldas += helytelen;
                } else if (holagolyo == legkis) {
                    megoldas += helyes;
                } else {
                    megoldas += vonal;
                }

            }
        }
        System.out.printf("%s\n", megoldas);
        for (int i = 1; i < palyahossz + 1; i++) {
            System.out.print(i + " ");
        }
        System.out.println(" ");
        System.out.printf(valasz2, tipp, holagolyo);
        if (jo) {
            System.out.printf(nyer, nyeremeny);
            System.out.printf(osszeg, penz);
        }
        if (rossztipp) {
            System.out.printf(veszt, feltesz);
            System.out.printf(osszeg, penz);
        }

    }
//
//    private static String bekeres() throws UnsupportedEncodingException {
//        String igaz="i";
//        String hamis="h";
//        Scanner keyboard = new Scanner(System.in);
//        System.out.println(" ");
//        System.out.println("Szeretnél-e pénzre játszani ? igen=i | nem=n");
//        String choiceString = keyboard.next();
//        
//        Scanner scan = new Scanner(new InputStreamReader(System.in, "ISO-8859-1"));
//        String valasz = scan.nextLine();
//
//        while (!valasz.equals(igaz) || !valasz.equals(hamis)) {
//            System.out.println("Hibás választ adott meg!");
//            System.out.println("Szeretnél-e pénzre játszani ? igen=i | nem=n");
//            valasz = scan.nextLine();
//        }
//        return valasz;
//    }

}
